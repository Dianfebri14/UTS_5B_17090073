<!-- about -->
<div id="about">
    <div class="container footer">
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <h1> <img src="assets/img/logoo.png" width="180px"></h1>
        </div>  
        <div class="text-right">
        <h5>Tentang | FAQ | Syarat & Ketentuan | Ketentuan Privasi</h5>
        </div>
    </div>
    <p class="text-center">0821-2356-8755</p>
    <p class="text-center">Info.semarak@mail.com</p>
    <p class="text-center">Jl. Gatot Subroto Rt 01 Rw 006</p>
    <p class="text-center">Kel.Pesurungan Lor, Kec.Margadana Kab. Tegal</p>
    <h4 class="text-center">Jawa Tengan - Indonesia</h4><br/>
  </div>
  <!-- about -->

  <!-- kaki -->
  <div id="kaki">
    <div class="container">
      <h5 class="text-center">©2019 - 2020 Semarak.com. Allright Reserved<br/>Made with by SemakarDevelop</h5>
    </div>
  </div>