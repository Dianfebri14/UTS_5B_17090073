<!DOCTYPE html>
<html>
<head>
    <title>Website Pertama</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<nav id="menu">
     <ul>
        <div id="heading">
            <a href="index.php" >Semarak</a>
            <!-- <img class="image" src="image/logo.jpg" width="30px" style="margin:1px;padding: 0px color:white;"> -->
        </div>
       
        <li><a href="index.php">Home</a></li>
        <li><a href="artikel.html">Event</a>
            <ul>
                <li> <a href="ul.html">Competition</a></li>
                <li> <a href="ol.html">Seminar</a></li>
                <li> <a href="ul.html">Expo</a></li>
                <li> <a href="ol.html">Bursa Kerja</a></li>
            </ul>
        </li>
        <li><a href="gambar.html">Ticket</a></li>
        <li><a href="#">Forum</a></li>
             <li><a href="form.html">Join Us</a></li>
       
    </ul>
</nav>

<div class=malasngoding-slider>
		<div class=isi-slider>  
			<img src="image/gambar1.jpg" alt="Gambar 1">
			<img src="image/gambar2.png" alt="Gambar 2">
			<img src="image/gambar3.jpg" alt="Gambar 3">
		</div>
	</div>
</html>