<nav class="navbar navbar-default navbar-static-top">
    <div class="container" id="navbar">
      <div class="navbar-header">
        <a href="#" class="navbar-brand navbar-link"><img src="assets/img/logo.png"></a>
        <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
      </div>
      <div class="collapse navbar-collapse" id="navcol-1">
        <ul class="nav navbar-nav navbar-right">
          <li role="presentation"><a href="index.php" >Home</a></li>
          <li role="presentation"><a href="event.php">Event</a></li>
          <li role="presentation"><a href="ticket.php">Ticket</a></li>
          <li role="presentation"><a href="forum.php">Forum</a></li>
          <li role="presentation"><a href="#" class="btn btn-primary" role="button">Join Us</a></li>
          <!-- <li role="presentation"><a href="#"><i class="glyphicon glyphicon-search"></i></a></li> -->
        </ul>
      </div>
    </div>
  </nav>